import Foundation
import WebKit

@MainActor
final class WebViewState: ObservableObject {
    @Published var isLoading = false
    @Published var estimatedProgress = 0.0
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var lastErrorMessage = ""

    weak var webView: WKWebView?

    func attach(_ webView: WKWebView) {
        self.webView = webView
        refreshNavigationState()
    }

    func reload() {
        webView?.reload()
    }

    func goBack() {
        guard webView?.canGoBack == true else { return }
        webView?.goBack()
    }

    func goForward() {
        guard webView?.canGoForward == true else { return }
        webView?.goForward()
    }

    func refreshNavigationState() {
        canGoBack = webView?.canGoBack ?? false
        canGoForward = webView?.canGoForward ?? false
    }
}
