import SwiftUI
import WebKit

struct WebAppView: UIViewRepresentable {
    let state: WebViewState
    private let appURL = URL(string: "https://torquetune.net")!

    func makeCoordinator() -> Coordinator {
        Coordinator(state: state)
    }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = []
        configuration.websiteDataStore = .default()

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = true
        webView.customUserAgent = "TorqueTune iOS App"
        webView.scrollView.contentInsetAdjustmentBehavior = .never

        context.coordinator.observe(webView)
        Task { @MainActor in
            state.attach(webView)
        }

        webView.load(URLRequest(url: appURL, cachePolicy: .reloadRevalidatingCacheData))
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        state.refreshNavigationState()
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        private weak var state: WebViewState?
        private var progressObservation: NSKeyValueObservation?

        init(state: WebViewState) {
            self.state = state
        }

        func observe(_ webView: WKWebView) {
            progressObservation = webView.observe(\.estimatedProgress, options: [.new]) { [weak self] webView, _ in
                Task { @MainActor in
                    self?.state?.estimatedProgress = webView.estimatedProgress
                }
            }
        }

        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            Task { @MainActor in
                state?.isLoading = true
                state?.refreshNavigationState()
            }
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            Task { @MainActor in
                state?.isLoading = false
                state?.estimatedProgress = 1
                state?.lastErrorMessage = ""
                state?.refreshNavigationState()
            }
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            finishWith(error)
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            finishWith(error)
        }

        private func finishWith(_ error: Error) {
            Task { @MainActor in
                state?.isLoading = false
                state?.lastErrorMessage = error.localizedDescription
                state?.refreshNavigationState()
            }
        }

        @available(iOS 15.0, *)
        func webView(
            _ webView: WKWebView,
            requestMediaCapturePermissionFor origin: WKSecurityOrigin,
            initiatedByFrame frame: WKFrameInfo,
            type: WKMediaCaptureType,
            decisionHandler: @escaping (WKPermissionDecision) -> Void
        ) {
            decisionHandler(.grant)
        }
    }
}
