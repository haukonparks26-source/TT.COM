import SwiftUI

@main
struct TorqueTuneApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
