import SwiftUI

struct ContentView: View {
    @StateObject private var state = WebViewState()

    var body: some View {
        ZStack(alignment: .top) {
            WebAppView(state: state)
                .ignoresSafeArea(.container, edges: .bottom)

            if state.isLoading {
                ProgressView(value: state.estimatedProgress)
                    .progressViewStyle(.linear)
                    .tint(.mint)
                    .frame(height: 3)
                    .transition(.opacity)
            }
        }
        .safeAreaInset(edge: .bottom) {
            HStack(spacing: 16) {
                Button {
                    state.goBack()
                } label: {
                    Image(systemName: "chevron.left")
                }
                .disabled(!state.canGoBack)

                Button {
                    state.goForward()
                } label: {
                    Image(systemName: "chevron.right")
                }
                .disabled(!state.canGoForward)

                Spacer()

                Text("TorqueTune")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)

                Spacer()

                Button {
                    state.reload()
                } label: {
                    Image(systemName: "arrow.clockwise")
                }
            }
            .font(.system(size: 17, weight: .semibold))
            .padding(.horizontal, 18)
            .padding(.vertical, 10)
            .background(.regularMaterial)
        }
    }
}
